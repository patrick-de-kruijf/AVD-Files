﻿<#
.SYNOPSIS
Creating Hostpool and add sessionhost servers to existing/new Hostpool.
.DESCRIPTION
This script add sessionhost servers to existing/new Hostpool
The supported Operating Systems Windows Server 2016.
.ROLE
Readers
#>

param(
    [Parameter(mandatory = $true)]
    [string]$profileLocation
)

# Setting ErrorActionPreference to stop script execution when error occurs
$ErrorActionPreference = "Stop"

try {
    Write-Information "Enabling Kerberos functions"
    $kerberosPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\Kerberos\Parameters"
    if (!(Test-Path $kerberosPath)) {
        New-Item -Path $kerberosPath -Force | Out-Null
    }
    New-ItemProperty -Path $kerberosPath -Name "CloudKerberosTicketRetrievalEnabled" -Value 1 -PropertyType DWORD -Force | Out-Null

    $aadAccountPath = "HKLM:\Software\Policies\Microsoft\AzureADAccount"
    if (!(Test-Path $aadAccountPath)) {
        New-Item -Path $aadAccountPath -Force | Out-Null
    }
    New-ItemProperty -Path $aadAccountPath -Name "LoadCredKeyFromProfile" -Value 1 -PropertyType DWORD -Force | Out-Null

    Write-Information "Resetting Primary Refresh Token"
    cmd /c "dsregcmd /RefreshPrt"
}   
catch {
    Throw "Enabling Kerberos functions not succesful, $_"
}
try {
    if ($profileLocation) {
        # Fslogix profile container
        $fslogixPath = "HKLM:\Software\FSLogix\Profiles"
        if (!(Test-Path $fslogixPath)) {
            New-Item -Path $fslogixPath -Force | Out-Null
        }
        New-ItemProperty -Path $fslogixPath -Name Enabled -Value 1 -PropertyType DWORD -Force | Out-Null
        New-ItemProperty -Path $fslogixPath -Name VHDLocations -Value $profileLocation -PropertyType String -Force | Out-Null
        New-ItemProperty -Path $fslogixPath -Name DeleteLocalProfileWhenVHDShouldApply -Value 1 -PropertyType DWORD -Force | Out-Null
        Write-Information "Configuring fslogix profile location"
    }
}
catch {
    Throw "Configuring FSLogix profile location not succesfully, $_"
}