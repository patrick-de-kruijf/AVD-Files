﻿<#
.SYNOPSIS
Creating Hostpool and add sessionhost servers to existing/new Hostpool.
.DESCRIPTION
This script add sessionhost servers to existing/new Hostpool
The supported Operating Systems Windows Server 2016.
.ROLE
Readers
#>

$ScriptPath = [system.io.path]::GetDirectoryName($PSCommandPath)

# Setting ErrorActionPreference to stop script execution when error occurs
$ErrorActionPreference = "Stop"

try {
    
    New-Item -ItemType Directory -Path C:\_Software -Force
    
    Invoke-WebRequest -Uri "https://github.com/notepad-plus-plus/notepad-plus-plus/releases/download/v8.3.3/npp.8.3.3.Installer.x64.exe" -OutFile C:\_Software\Npp.exe -UseBasicParsing
    Invoke-WebRequest -Uri "https://ardownload2.adobe.com/pub/adobe/reader/win/AcrobatDC/2200120085/AcroRdrDC2200120085_en_US.exe" -OutFile C:\_Software\AdobeReader.exe -UseBasicParsing
    Set-Location C:\_Software

    & "C:\_Software\npp.exe" /S
    & "C:\_Software\AdobeReader.exe" /sAll /rs /msi EULA_ACCEPT=YES

}   
catch {
    Throw "Installing Software was not succesful, $_"
}