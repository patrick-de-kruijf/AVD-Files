﻿<#
.SYNOPSIS
Creating Hostpool and add sessionhost servers to existing/new Hostpool.
.DESCRIPTION
This script add sessionhost servers to existing/new Hostpool
The supported Operating Systems Windows Server 2016.
.ROLE
Readers
#>

$ScriptPath = [system.io.path]::GetDirectoryName($PSCommandPath)

# Setting ErrorActionPreference to stop script execution when error occurs
$ErrorActionPreference = "Stop"

try {
    
    New-Item -ItemType Directory -Path C:\_Software -Force
    
    Invoke-WebRequest -Uri "https://github.com/notepad-plus-plus/notepad-plus-plus/releases/download/v8.3.3/npp.8.3.3.Installer.x64.exe" -OutFile C:\_Software\Npp.exe
    Invoke-WebRequest -Uri "https://get.adobe.com/nl/reader/completion/?installer=Reader_DC_2022.001.20085_English_for_Windows&stype=7519&direct=true&standalone=1" -OutFile C:\_Software\AdobeReader.exe

    Set-Location C:\_Software

    & "C:\_Software\npp.exe" /S
    & "C:\_Software\AdobeReader.exe" /sAll /rs /msi EULA_ACCEPT=YES

}   
catch {
    Throw "Installing Software was not succesful, $_"
}