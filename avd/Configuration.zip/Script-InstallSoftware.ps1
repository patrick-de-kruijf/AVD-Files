﻿<#
.SYNOPSIS
Creating Hostpool and add sessionhost servers to existing/new Hostpool.
.DESCRIPTION
This script add sessionhost servers to existing/new Hostpool
The supported Operating Systems Windows Server 2016.
.ROLE
Readers
#>

param(
    [Parameter(mandatory = $true)]
    [string]$BRXLICENSESERVER
)

$ScriptPath = [system.io.path]::GetDirectoryName($PSCommandPath)

# Setting ErrorActionPreference to stop script execution when error occurs
$ErrorActionPreference = "Stop"

try {
    
    New-Item -ItemType Directory -Path C:\_Software -Force
    
    Invoke-WebRequest -Uri "https://github.com/notepad-plus-plus/notepad-plus-plus/releases/download/v8.3.3/npp.8.3.3.Installer.x64.exe" -OutFile C:\_Software\Npp.exe -UseBasicParsing
    Invoke-WebRequest -Uri "https://ardownload2.adobe.com/pub/adobe/reader/win/AcrobatDC/2200120085/AcroRdrDC2200120085_en_US.exe" -OutFile C:\_Software\AdobeReader.exe -UseBasicParsing
    Invoke-WebRequest -Uri "https://saimssharesprod001.file.core.windows.net/software/BricsCAD-V22.2.03-1-en_US(x64).msi" -OutFile C:\_Software\BricsCAD.msi -UseBasicParsing


}   
catch {
    Throw "Downloading Software was not succesful, $_"
}

try {
    
    & "C:\_Software\npp.exe" /S

}   
catch {
    Throw "Installing Notepad++ was not succesful, $_"
}

try {
    
    & "C:\_Software\AdobeReader.exe" /sAll /rs /msi EULA_ACCEPT=YES

}   
catch {
    Throw "Installing Adobe Reader was not succesful, $_"
}


try {
    
    & msiexec /i "C:\_Software\BricsCAD.msi" /qn ADDDESKTOPSHORTCUT="" SHOWRELEASENOTES="" BRXLICENSESERVER="$BRXLICENSESERVER"

}   
catch {
    Throw "Installing BricsCAD was not succesful, $_"
}


try {    

    $sourceZIP = "https://saimssharesprod001.file.core.windows.net/software/ims.zip"
    Expand-Archive -Path $sourceZIP -DestinationPath "C:\IMS"

}   
catch {
    Throw "Copying/Installing IMS was not succesful, $_"
}